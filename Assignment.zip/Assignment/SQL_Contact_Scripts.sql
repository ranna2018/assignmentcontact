Use Master
Go
If ( DB_ID('Hiring06232018') Is Not Null )
Begin
	Drop Database Hiring06232018
End
Go
Create Database [Hiring06232018]
Go
Use [Hiring06232018]
Go
If ( OBJECT_ID('Contact', 'U') Is Not Null )
Begin
	Drop table dbo.Contact
End
Go
-- Creates contact table with audit columns
Create Table dbo.Contact
(
	ContactId Int Not Null Identity(1,1),
	FirstName NVarchar(100) Not Null,
	LastName NVarchar(100) Not Null,
	Email NVarchar(50) Not Null,
	Phone NVarchar(25) Not Null,
	IsActive bit Not Null Default(1),
	CreatedDate DateTime Not Null,
	CreatedBy Int Not Null,
	ModifiedDate DateTime,
	ModifiedBy Int,
	Constraint PK_Contact_Contact_Id Primary Key (ContactId)
)


-- Test insert statement
--Insert Into dbo.Contact(FirstName, LastName, Email, Phone, IsActive, CreatedBy, CreatedDate)
--Values('Jhon', 'Doe', 'Jhon.Doe@gmail.com', 1234567890, 1, 1, GETDATE());