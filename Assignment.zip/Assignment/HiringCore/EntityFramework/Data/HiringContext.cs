using Microsoft.EntityFrameworkCore;
using Hiring.Models;
namespace Hiring.Core.EntityFramework.Data
{
    public class HiringContext: DbContext
    {
        public HiringContext(DbContextOptions<HiringContext> options) : base(options)
        {

        }   
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        } 

        public DbSet<Contact> Contacts { get; set; }
    }
}