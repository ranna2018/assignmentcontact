using System.ComponentModel.DataAnnotations.Schema;
using Hiring.Audit;
namespace Hiring.Models
{
    [Table("Contact", Schema="dbo")]
    public class Contact : AuditLog
    {
        [Column("ContactId")]
        public int ContactId { get; set; }
        [Column("FirstName")]
        public string FirstName { get; set; }
        [Column("LastName")]
        public string LastName { get; set; }
        [Column("Email")]
        public string Email { get; set; }
        [Column("Phone")]
        public string Phone { get; set; }
        [Column("IsActive")]
        public bool IsActive { get; set; }
    }
}