using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hiring.Audit
{
    public class AuditLog
    {
        private DateTime _createdDate;
        [Column("CreatedDate")]
        public DateTime CreatedDate
        {
            get{
                return (_createdDate == null || _createdDate == DateTime.MinValue) ? DateTime.Now : _createdDate;
            }
            set{
                _createdDate = value;
            }
        }
        [Column("CreatedBy")]
        public int CreatedBy
        {
            get; set;
        }
        [Column("ModifiedDate")]
        public DateTime? ModifiedDate
        {
            get; set;
        }
        [Column("ModifiedBy")]
        public int? ModifiedBy
        {
            get; set;
        }
    }
}