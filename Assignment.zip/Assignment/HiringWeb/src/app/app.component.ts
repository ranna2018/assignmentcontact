import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/primeng';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  items: MenuItem[];
  constructor(private route: Router){}
  ngOnInit(){
    this.items = [
      {label: 'Add', command: () => {
          this.route.navigate(['/contact/add']);
      }},
      {label: 'Show', command: () => {
        this.route.navigate(['/contact/list'])
      }}
    ]
  }
}
