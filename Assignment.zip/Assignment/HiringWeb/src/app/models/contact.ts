export class Contact {
    constructor(
    public contactId?: number,
    public firstName?: string,
    public lastName?: string,
    public phone?: string,
    public email?: string,
    public isActive?: boolean,
    public userId?: number
    ){}
}