import { HttpService } from './services/http.service';
import { ContactService } from './services/contact.service';
import { ContactComponent } from './contact/contact.component';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ContactModule } from './contact/contact.module';
import { RouterModule } from '@angular/router';
import { IndexComponent } from './contact/index.component';
import { CommonModule } from '@angular/common';
import { DropdownModule, ConfirmationService, ConfirmDialogModule } from 'primeng/primeng';
import { SplitButtonModule } from 'primeng/splitbutton';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { TableModule } from 'primeng/table';
import { GrowlModule } from 'primeng/growl';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    RouterModule.forRoot([
      { path: '', component: IndexComponent },
      { path: '**', component: IndexComponent },
    ]),
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    HttpModule,
    DropdownModule,
    GrowlModule,
    TableModule,
    SplitButtonModule,
    ConfirmDialogModule,
    ContactModule
  ],
  providers: [ContactService, HttpService, ConfirmationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
