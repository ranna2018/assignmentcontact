import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { ContactService } from './../services/contact.service';
import { CommonModule } from '@angular/common';
import { IndexComponent } from './index.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ContactComponent } from './contact.component';
import { NgModule } from '@angular/core';
import { ContactDetailComponent } from './detail.component';
import { PanelModule, ButtonModule, DropdownModule, ConfirmDialogModule } from 'primeng/primeng';
import { ContactRoutingModule } from './contact-routing.module';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { InputMaskModule } from 'primeng/inputmask';
import { TableModule } from 'primeng/table';
import { GrowlModule } from 'primeng/growl';

@NgModule({
    imports: [
        ReactiveFormsModule,
        FormsModule,
        PanelModule,
        ButtonModule,
        CommonModule,
        MessageModule,
        MessagesModule,
        DropdownModule,
        GrowlModule,
        TableModule,
        InputMaskModule,
        ConfirmDialogModule,
        ContactRoutingModule
    ],
    exports: [
        ContactComponent,
        ContactDetailComponent,
        IndexComponent
    ],
    declarations: [
        ContactComponent,
        ContactDetailComponent,
        IndexComponent
    ],
    providers: []
})
export class ContactModule {

}