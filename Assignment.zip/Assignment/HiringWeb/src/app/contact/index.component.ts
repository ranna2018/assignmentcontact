import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/primeng';
@Component({
  selector: 'index',
  templateUrl: './index.component.html'
})
export class IndexComponent implements OnInit{
  items: MenuItem[];
  ngOnInit(){
    this.items = [
      {label: 'Add', icon: 'fa-refresh', command: () => {
          //this.update();
      }},
      {label: 'Show', icon: 'fa-close', command: () => {
          //this.delete();
      }}
    ]
  }
}