import { ContactComponent } from './contact.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactDetailComponent } from './detail.component';
const routes: Routes = [
    {path: 'contact/add', component: ContactComponent},
    {path: 'contact/edit/:contactId', component: ContactComponent},
    {path: 'contact/list', component: ContactDetailComponent}
];
@NgModule({
    imports:[RouterModule.forChild(routes)],
    exports:[RouterModule]
})
export class ContactRoutingModule{

}