import { Contact } from './../models/contact';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ContactService } from '../services/contact.service';
import { ConfirmationService } from 'primeng/components/common/confirmationservice';
import { Message } from 'primeng/components/common/api';

@Component({
  selector: 'contact-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class ContactDetailComponent implements OnInit {

  contactList: Contact[] = [];
  msgs: Message[] = [];
  constructor(private contactService: ContactService,
    private router: Router,
    private confirmationService: ConfirmationService
  ) {

  }
  ngOnInit() {
    this.getList();
  }
  getList(){
    this.contactList = [];
    this.contactService.list().subscribe(result => {
      this.contactList = result;
    });
  }
  onNew() {
    this.router.navigate(['contact/add']);
  }
  onEdit(event: Contact) {
    this.router.navigate(['contact/edit/' + event.contactId]);
  }
  onDelete(id: number) {
    this.confirmationService.confirm({
      message: "Are you sure to inactivate?",
      accept: () => {
        this.contactService.delete(id).subscribe(() => {
          this.getList();
          this.msgs = [];
          this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Contact has been inactivated.' });
        });
      },
      reject: () => {
      }
    })
  }
}