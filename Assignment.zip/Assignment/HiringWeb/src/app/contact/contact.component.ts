import { ActivatedRoute, Router } from '@angular/router';
import { ContactService } from './../services/contact.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Contact } from '../models/contact';
import { SelectItem } from 'primeng/primeng';
import { Message } from 'primeng/components/common/api';

@Component({
    selector: 'contact',
    templateUrl: './contact.component.html',
    styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
    contactFormGroup: FormGroup;
    contact: Contact = new Contact();
    statuses: SelectItem[] = [];
    msgs: Message[] = [];
    formSubmitted: boolean = false;
    constructor(private fb: FormBuilder,
        private contactService: ContactService,
        private route: ActivatedRoute,
        private router: Router
    ) {

    }

    ngOnInit() {
        this.route.params.subscribe(param => {
            this.contact.contactId = +param['contactId'] || 0;
            if (this.contact.contactId != 0) {
                this.contactService.get(this.contact.contactId).subscribe(result => {
                    this.contact = result;
                });
            }
        })
        this.createForm();
        this.statuses.push({ label: "Active", value: true });
        this.statuses.push({ label: "Inactive", value: false })

        this.contact.isActive = true;
        this.contact.userId = 1; //hard coded
    }
    createForm() {
        this.contactFormGroup = this.fb.group({
            firstName: ["", [Validators.required, Validators.maxLength(100)]],
            lastName: ["", [Validators.required, Validators.maxLength(100)]],
            email: ["", [Validators.required, Validators.maxLength(50), Validators.pattern("^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$")]],
            phone: ["", [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("[0-9]*")]],
            isActive: ["", Validators.required]
        })
    }
    save() {
        this.formSubmitted = true;
        if (this.contactFormGroup.valid) {
            if (this.contact.contactId == 0) {
                this.contactService.save(this.contact).subscribe(() => {
                    this.msgs = [];
                    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Contact information has been saved' });
                    this.router.navigate(['contact/list']);
                });
            }
            else {
                this.contactService.put(this.contact).subscribe(() => {
                    this.msgs = [];
                    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Contact information has been updated' });
                    this.router.navigate(['contact/list']);
                });
            }

        }
    }
    goHome() {
        this.router.navigate(['']);
    }
    get firstName() {
        return this.contactFormGroup.get('firstName');
    }
    get lastName() {
        return this.contactFormGroup.get('lastName');
    }
    get email() {
        return this.contactFormGroup.get('email');
    }
    get phone() {
        return this.contactFormGroup.get('phone');
    }
    get isActive() {
        return this.contactFormGroup.get('isActive');
    }
}