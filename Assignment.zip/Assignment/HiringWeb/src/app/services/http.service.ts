import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
import { Http, XHRBackend, RequestOptions, RequestOptionsArgs, Headers } from '@angular/http';
import { } from 'https';
import { Observable } from 'rxjs-compat';

@Injectable()
export class HttpService extends Http {
    constructor(backend: XHRBackend, defaultOptions: RequestOptions, private http: Http) {
        super(backend, defaultOptions);
    }
    get(url: string, options?: RequestOptionsArgs): Observable<any> {
        return this.http.get(this.getFullUrl(url), this.noCacheRequestOptions(options))
            .catch(this.onCatch)
            .do((res: Response) => {
                this.onSuccess(res);
            }, (error: any) => {
                this.onError(error);
            })
            .finally(() => {
            });
    }

    post(url: string, body: string, options?: RequestOptionsArgs): Observable<any> {
        return this.http.post(this.getFullUrl(url), body, this.requestOptions(options))
            .catch(this.onCatch)
            .do((res: Response) => {
                this.onSuccess(res);
            }, (error: any) => {
                this.onError(error);
            })
            .finally(() => {
            });
    }
    put(url: string, body: string, options?: RequestOptionsArgs): Observable<any> {
        return this.http.put(this.getFullUrl(url), body, this.requestOptions(options))
            .catch(this.onCatch)
            .do((res: Response) => {
                this.onSuccess(res);
            }, (error: any) => {
                this.onError(error);
            })
            .finally(() => {
            });
    }
    delete(url: string, options?: RequestOptionsArgs): Observable<any> {
        return this.http.delete(this.getFullUrl(url), this.requestOptions(options))
            .catch(this.onCatch)
            .do((res: Response) => {
                this.onSuccess(res);
            }, (error: any) => {
                this.onError(error);
            })
            .finally(() => {
            });
    }
    private requestOptions(options?: RequestOptionsArgs): RequestOptionsArgs {
        if (options == null) {
            options = new RequestOptions();
        }
        if (options.headers == null) {
            options.headers = new Headers({ 'Content-Type': 'application/json' });
        }
        return options;
    }

    private getFullUrl(url: string): string {
        return environment.apiUrl + url;
    }

    private onCatch(error: any, caught: Observable<any>): Observable<any> {
        return Observable.throw(error);
    }

    private onSuccess(res: Response): void {
    }

    private onError(res: Response): void {
        console.log('Error, status code: ' + res.status);
    }

    private noCacheRequestOptions(options?: RequestOptionsArgs): RequestOptionsArgs {
        if (options == null) {
            options = new RequestOptions();
        }
        options.headers = new Headers({
            // 'Access-Control-Allow-Origin': '*',
            // 'Access-Control-Allow-Methods': 'HEAD, GET, POST, PUT, PATCH, DELETE',
            // 'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token',
            'If-Modified-Since': 'Mon, 26 Jul 1997 05:00:00 GMT',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        });
        return options;
    }
}