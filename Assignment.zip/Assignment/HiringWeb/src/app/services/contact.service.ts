import { environment } from './../../environments/environment.prod';
import { Contact } from './../models/contact';
import { Observable } from 'rxjs/Observable';
import { Injectable } from "@angular/core";
import { HttpService } from "./http.service";
import 'rxjs/Rx';
import 'rxjs/operator/map';
import { stringify } from 'querystring';

@Injectable()
export class ContactService {
    url : string = "api/Contact/";
    constructor(private httpService: HttpService) { }

    get(id: number): Observable<Contact> {
        return this.httpService.get(this.url + "Get/" + id).map(res => res.json());
    }
    list():Observable<Contact[]>{
        return this.httpService.get(this.url + "List").map(res => res.json());
    }
    save(contact: Contact) {
        return this.httpService.post(this.url + "Save" , JSON.stringify(contact)).map((res:Response) => {return res.json()});
    }
    put(contact: Contact){
        return this.httpService.put(this.url + "Update", JSON.stringify(contact)).map((res:Response) => {return res.json()});
    }
    delete(id: number){
        return this.httpService.post(this.url + "Delete/" + id, "").map((res:Response) => {return res.json()});
    }
}