using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hiring.Core.EntityFramework.Data;
using Hiring.Models;
using Hiring.ViewModels;
namespace Hiring.Services {
    public class ContactService : IContactService {
        private readonly HiringContext _hiringContext;
        public ContactService (HiringContext hiringContext) {
            _hiringContext = hiringContext;
        }

        public ContactViewModel Get (int contactId) {
            var contactViewModel = _hiringContext.Contacts
                .Where (c => c.ContactId == contactId)
                .Select (c => new ContactViewModel {
                    ContactId = c.ContactId,
                        FirstName = c.FirstName,
                        LastName = c.LastName,
                        Email = c.Email,
                        Phone = c.Phone,
                        IsActive = c.IsActive
                }).FirstOrDefault ();

            return contactViewModel;
        }

        public IList<ContactViewModel> List () {
            return _hiringContext.Contacts.Select (c => new ContactViewModel {
                ContactId = c.ContactId,
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    Email = c.Email,
                    Phone = c.Phone,
                    IsActive = c.IsActive
            }).OrderBy (c => c.FirstName).ThenBy (c => c.LastName).ToList ();
        }

        public bool Save (ContactViewModel cvm) {
            var contact = new Contact () {
                ContactId = cvm.ContactId,
                FirstName = cvm.FirstName,
                LastName = cvm.LastName,
                Email = cvm.Email,
                Phone = cvm.Phone,
                IsActive = cvm.IsActive,
                CreatedBy = cvm.UserId
            };
            _hiringContext.Contacts.Add (contact);
            _hiringContext.SaveChanges ();
            return true;
        }

        public bool Update (ContactViewModel cvm) {
            var contact = _hiringContext.Contacts
                .Where (c => c.ContactId == cvm.ContactId)
                .FirstOrDefault ();
            if (contact != null) {
                contact.FirstName = cvm.FirstName;
                contact.LastName = cvm.LastName;
                contact.Email = cvm.Email;
                contact.Phone = cvm.Phone;
                contact.IsActive = cvm.IsActive;
                contact.ModifiedBy = cvm.UserId;
                contact.ModifiedDate = DateTime.Now;

                _hiringContext.SaveChanges ();
                return true;
            }
            return false;
        }
        public bool Delete (int id) {
            var contact = _hiringContext.Contacts.Where (c => c.ContactId == id).FirstOrDefault ();
            if (contact != null) {
                contact.IsActive = false;
                _hiringContext.SaveChanges ();
                return true;
            }
            return false;
        }
    }
}