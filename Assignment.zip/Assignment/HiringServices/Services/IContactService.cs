using System.Collections.Generic;
using Hiring.ViewModels;
namespace Hiring.Services {
    public interface IContactService {
        ContactViewModel Get (int id);
        IList<ContactViewModel> List ();
        bool Save (ContactViewModel cvm);
        bool Update (ContactViewModel cvm);
        bool Delete (int id);
    }
}