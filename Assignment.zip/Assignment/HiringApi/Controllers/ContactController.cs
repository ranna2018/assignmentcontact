﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hiring.Services;
using Hiring.ViewModels;
using log4net.Core;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace HiringApi.Controllers {
    [Produces ("application/json")]
    [Route ("api/Contact")]
    public class ContactController : Controller {
        private IContactService _contactService;
        public ContactController (IContactService contactService ) {
            _contactService = contactService;
        }
        [HttpGet ("Get/{id}")]
        public IActionResult Get (int id) {
            var contact = _contactService.Get (id);
            if(contact != null)
                return new OkObjectResult (contact);
            else
            {
                return new NotFoundObjectResult (contact);
            }
        }

        [HttpGet ("List")]
        public IActionResult List () {
            return new OkObjectResult (_contactService.List ());
        }

        [HttpPost ("Save")]
        public IActionResult Post ([FromBody] ContactViewModel cvm) {
            return new OkObjectResult (_contactService.Save (cvm));
        }

        [HttpPut ("Update")]
        public IActionResult Put ([FromBody] ContactViewModel cvm) {
            return new OkObjectResult(_contactService.Update(cvm));
         }

        [HttpPost ("Delete/{id}")]
        public IActionResult Post (int id) { 
            return new OkObjectResult(_contactService.Delete(id));
        }
    }
}